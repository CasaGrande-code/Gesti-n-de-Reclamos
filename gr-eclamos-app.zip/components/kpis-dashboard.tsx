"use client"

import { useEffect, useState } from "react"
import { getSupabaseClient } from "@/lib/supabase-client"
import { exportClaimsToExcel } from "@/lib/excel-export"
import { Button } from "@/components/ui/button"
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts"

export function KPIsDashboard() {
  const [claims, setClaims] = useState([])
  const [kpis, setKpis] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const supabase = getSupabaseClient()

  const COLORS = ["#1e5a8e", "#3b82f6", "#10b981", "#f59e0b", "#ef4444"]

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [claimsRes, kpisRes] = await Promise.all([
          supabase.from("claims").select("*"),
          supabase.from("kpis").select("*"),
        ])

        if (claimsRes.error) throw claimsRes.error
        if (kpisRes.error) throw kpisRes.error

        setClaims(claimsRes.data || [])
        setKpis(kpisRes.data || [])
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [supabase])

  const getStatusLabel = (status: string) => {
    const labels: { [key: string]: string } = {
      received: "Recibido",
      in_analysis: "En Análisis",
      resolved: "Resuelto",
      closed: "Cerrado",
    }
    return labels[status] || status
  }

  const statusData = claims.reduce((acc: any[], claim) => {
    const status = claim.claim_status
    const existing = acc.find((d) => d.name === getStatusLabel(status))
    if (existing) {
      existing.value += 1
    } else {
      acc.push({ name: getStatusLabel(status), value: 1 })
    }
    return acc
  }, [])

  const timeAnalysis = claims
    .filter((c) => c.reception_date && c.shipping_date)
    .map((c) => ({
      code: c.claim_code,
      days: Math.floor(
        (new Date(c.shipping_date).getTime() - new Date(c.reception_date).getTime()) / (1000 * 60 * 60 * 24),
      ),
    }))
    .slice(-10)

  const responseTimeData = kpis
    .sort((a, b) => {
      if (a.year !== b.year) return b.year - a.year
      return b.quarter - a.quarter
    })
    .slice(0, 6)

  if (isLoading) {
    return <div className="flex justify-center items-center h-96">Cargando KPIs...</div>
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-end">
        <Button onClick={() => exportClaimsToExcel(claims, kpis)} variant="outline">
          Exportar a Excel
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Estado de Reclamos */}
        <div className="bg-card p-6 rounded-lg border">
          <h3 className="text-lg font-semibold mb-4">Estado de Reclamos</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={statusData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${value}`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {statusData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Tiempo de Respuesta por Trimestre */}
        <div className="bg-card p-6 rounded-lg border">
          <h3 className="text-lg font-semibold mb-4">KPI Tiempo de Atención por Trimestre</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={responseTimeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={(d) => `Q${d.quarter}/${d.year}`} angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="response_time_kpi" fill="#1e5a8e" name="Tiempo Atención" />
              <Bar dataKey="shipping_days_kpi" fill="#3b82f6" name="Días Despacho" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Tiempo de Despacho */}
        <div className="bg-card p-6 rounded-lg border">
          <h3 className="text-lg font-semibold mb-4">Tiempo Despacho-Producción (Últimos 10)</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={timeAnalysis}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="code" angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="days" fill="#10b981" name="Días" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* KPI Comercial por Trimestre */}
        <div className="bg-card p-6 rounded-lg border">
          <h3 className="text-lg font-semibold mb-4">KPI Comercial por Trimestre</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={responseTimeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey={(d) => `Q${d.quarter}/${d.year}`} angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="commercial_kpi" stroke="#1e5a8e" name="KPI Comercial" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tabla de Resumen */}
      <div className="bg-card p-6 rounded-lg border">
        <h3 className="text-lg font-semibold mb-4">Resumen de Reclamos</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white border border-slate-200 rounded-lg">
            <div className="text-sm text-slate-600 font-medium">Total Reclamos</div>
            <div className="text-3xl font-bold text-slate-900">{claims.length}</div>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-lg">
            <div className="text-sm text-slate-600 font-medium">Resueltos</div>
            <div className="text-3xl font-bold text-slate-900">
              {claims.filter((c) => c.claim_status === "resolved").length}
            </div>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-lg">
            <div className="text-sm text-slate-600 font-medium">En Análisis</div>
            <div className="text-3xl font-bold text-slate-900">
              {claims.filter((c) => c.claim_status === "in_analysis").length}
            </div>
          </div>
          <div className="p-4 bg-white border border-slate-200 rounded-lg">
            <div className="text-sm text-slate-600 font-medium">Cerrados</div>
            <div className="text-3xl font-bold text-slate-900">
              {claims.filter((c) => c.claim_status === "closed").length}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
