// Proveedor de sincronización offline
"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { setupSyncListener, syncPendingClaims } from "@/lib/sync-manager"

export function SyncProvider({ children }: { children: React.ReactNode }) {
  const [syncStatus, setSyncStatus] = useState<"idle" | "syncing" | "success" | "error">("idle")

  useEffect(() => {
    // Registrar service worker solo en producción (no en preview)
    if ("serviceWorker" in navigator && typeof window !== "undefined") {
      // Solo registrar si estamos en un dominio que permite Service Workers
      if (
        window.location.protocol === "https:" ||
        window.location.hostname === "localhost"
      ) {
        navigator.serviceWorker
          .register("/sw.js", { scope: "/" })
          .then((registration) => {
            console.log("[v0] Service Worker registered successfully")
          })
          .catch((error) => {
            // En preview de v0, el SW puede no registrarse - eso está bien
            // La app seguirá funcionando con IndexedDB para sincronización offline
            console.log(
              "[v0] Service Worker not available in this environment (normal for preview)"
            )
          })
      }
    }

    // Setup sincronización - esto funciona sin Service Worker
    setupSyncListener()

    // Sincronizar al cargar la app
    const syncOnLoad = async () => {
      if (navigator.onLine) {
        setSyncStatus("syncing")
        try {
          const result = await syncPendingClaims()
          if (result.success && result.synced > 0) {
            setSyncStatus("success")
            setTimeout(() => setSyncStatus("idle"), 3000)
          }
        } catch (error) {
          console.log("[v0] Sync on load - no pending data or network issue")
          setSyncStatus("idle")
        }
      }
    }

    syncOnLoad()
  }, [])

  return <>{children}</>
}
