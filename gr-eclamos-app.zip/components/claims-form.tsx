"use client"

import React from "react"

import { useState, useEffect, useRef } from "react"
import { getSupabaseClient } from "@/lib/supabase-client"
import { saveClaimOffline } from "@/lib/offline-store"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "sonner"
import {
  CLIENT_TYPE_OPTIONS,
  RECEPTION_METHOD_OPTIONS,
  PRODUCT_OPTIONS,
  BRAND_OPTIONS,
  PRESENTATION_OPTIONS,
  CLAIM_TYPE_OPTIONS,
  STATUS_OPTIONS,
} from "@/lib/claim-options"

export function ClaimsForm() {
  const [formData, setFormData] = useState({
    claim_code: "",
    year: "",
    company: "",
    client: "",
    client_requirement: "",
    shipping_location: "",
    client_type: "",
    received_through: "",
    product: "",
    brand: "",
    presentation: "",
    batch_number: "",
    production_date: "",
    shipping_date: "",
    reception_date: new Date().toISOString().split("T")[0],
    claim_type: "",
    commercial_responsible: "",
    claim_description: "",
    observations: "",
    media_urls: [] as string[],
  })

  const [isLoading, setIsLoading] = useState(false)
  const [isOnline, setIsOnline] = useState(navigator.onLine)
  const [savedClaimId, setSavedClaimId] = useState<string | null>(null)
  const [showSuccessToast, setShowSuccessToast] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const supabase = getSupabaseClient()

  // Detectar conexión de red
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  const handleChange = (e: any) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleMediaUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return

    const newUrls: string[] = []
    for (let i = 0; i < files.length; i++) {
      const file = files[i]
      const reader = new FileReader()
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string
        newUrls.push(dataUrl)
        if (newUrls.length === files.length) {
          setFormData((prev) => ({
            ...prev,
            media_urls: [...prev.media_urls, ...newUrls],
          }))
          toast.success(`${files.length} archivo(s) agregado(s)`)
        }
      }
      reader.readAsDataURL(file)
    }
  }

  const removeMedia = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      media_urls: prev.media_urls.filter((_, i) => i !== index),
    }))
  }

  const handleSubmit = async (e: any) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const claimData = {
        claim_code: formData.claim_code,
        year: formData.year,
        company: formData.company,
        client: formData.client,
        client_requirement: formData.client_requirement || null,
        shipping_location: formData.shipping_location,
        client_type: formData.client_type,
        commercial_responsible: formData.commercial_responsible || null,
        claim_type: formData.claim_type || null,
        received_by: null,
        reception_date: new Date(formData.reception_date).toISOString(),
        reception_date_sig: new Date().toISOString(),
        received_through: formData.received_through,
        product: formData.product,
        brand: formData.brand,
        presentation: formData.presentation || null,
        batch_number: formData.batch_number || null,
        production_date: new Date(formData.production_date).toISOString(),
        shipping_date: new Date(formData.shipping_date).toISOString(),
        claim_description: formData.claim_description || null,
        root_cause: formData.claim_type || null,
        claim_status: "received",
        responsible_process: formData.commercial_responsible || null,
        status_reason: null,
        first_response_date: null,
        second_response_date: null,
        observations: formData.observations,
        media_urls: formData.media_urls.length > 0 ? formData.media_urls : [],
      }

      if (isOnline) {
        const { data, error } = await supabase.from("claims").insert([claimData]).select()

        if (error) {
          console.error("[v0] Error en Supabase:", error)
          throw error
        }

        const claimId = data?.[0]?.id
        setSavedClaimId(claimId || "")
        setShowSuccessToast(true)
        
        // Ocultar toast después de 4 segundos
        setTimeout(() => {
          setShowSuccessToast(false)
        }, 4000)
        
        toast.success("Reclamo creado exitosamente")
      } else {
        await saveClaimOffline(claimData)
        toast.info("Reclamo guardado localmente")
      }
    } catch (error: any) {
      console.error("[v0] Error guardando reclamo:", error)
      const errorMessage = error?.message || "Error desconocido al guardar"
      const displayMessage = errorMessage.includes("invalid input syntax") 
        ? "Error: El campo 'N° de Factura' debe contener un número o formato válido"
        : errorMessage.includes("foreign key")
        ? "Error: Los datos no son válidos, verifica todos los campos"
        : `Error al guardar: ${errorMessage}`
      
      toast.error(displayMessage)
    } finally {
      setIsLoading(false)
    }
  }

  // Validación de campos requeridos
  const isFormValid = () => {
    return (
      formData.claim_code &&
      formData.year &&
      formData.company &&
      formData.client &&
      formData.commercial_responsible &&
      formData.reception_date &&
      formData.product &&
      formData.brand &&
      formData.production_date &&
      formData.shipping_date &&
      formData.client_type &&
      formData.received_through
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-4xl">
      {/* VALIDACIÓN */}
      {!isFormValid() && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
          ⚠️ Por favor completa todos los campos requeridos (marcados con *)
        </div>
      )}

      {/* SECCIÓN 1: DATOS DE RECEPCIÓN - ARRIBA */}
      <div className="bg-white p-6 rounded-lg border border-slate-200">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Datos de Recepción</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900">Responsable de Comercial *</label>
            <Input 
              type="text" 
              name="commercial_responsible" 
              value={formData.commercial_responsible} 
              onChange={handleChange} 
              required
              placeholder="Nombre de quien envía el formulario"
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900">Recepción de Reclamo - Comercial *</label>
            <Input 
              type="date" 
              name="reception_date" 
              value={formData.reception_date} 
              onChange={handleChange} 
              required 
              className="bg-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900">Código de Reclamo *</label>
            <Input 
              type="text" 
              name="claim_code" 
              value={formData.claim_code} 
              onChange={handleChange} 
              required 
              placeholder="REC-001"
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold mb-2 text-slate-900">N° de Factura *</label>
            <Input 
              type="text" 
              name="year" 
              value={formData.year} 
              onChange={handleChange} 
              required 
              className="bg-white"
              placeholder="Ej: FAC-2024-001"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 2: INFORMACIÓN GENERAL */}
      <div className="border-2 border-slate-200 p-6 rounded-lg">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Información General</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Empresa *</label>
            <Input 
              type="text" 
              name="company" 
              value={formData.company} 
              onChange={handleChange} 
              required 
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Cliente *</label>
            <Input 
              type="text" 
              name="client" 
              value={formData.client} 
              onChange={handleChange} 
              required 
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Tipo de Cliente *</label>
            <Select value={formData.client_type} onValueChange={(value) => handleSelectChange("client_type", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar tipo de cliente" />
              </SelectTrigger>
              <SelectContent>
                {CLIENT_TYPE_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Requerimiento de Cliente</label>
            <Input 
              type="text" 
              name="client_requirement" 
              value={formData.client_requirement} 
              onChange={handleChange} 
              className="bg-white"
              placeholder="Especificar requerimiento particular"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Lugar de Despacho *</label>
            <Input
              type="text"
              name="shipping_location"
              value={formData.shipping_location}
              onChange={handleChange}
              required
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Recepcionado a través de *</label>
            <Select value={formData.received_through} onValueChange={(value) => handleSelectChange("received_through", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar método de recepción" />
              </SelectTrigger>
              <SelectContent>
                {RECEPTION_METHOD_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Tipo de Reclamo *</label>
            <Select value={formData.claim_type} onValueChange={(value) => handleSelectChange("claim_type", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar tipo de reclamo" />
              </SelectTrigger>
              <SelectContent>
                {CLAIM_TYPE_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* SECCIÓN 3: INFORMACIÓN DEL PRODUCTO */}
      <div className="border-2 border-slate-200 p-6 rounded-lg">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Información del Producto</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">Producto *</label>
            <Select value={formData.product} onValueChange={(value) => handleSelectChange("product", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar producto" />
              </SelectTrigger>
              <SelectContent>
                {PRODUCT_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Marca *</label>
            <Select value={formData.brand} onValueChange={(value) => handleSelectChange("brand", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar marca" />
              </SelectTrigger>
              <SelectContent>
                {BRAND_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Presentación</label>
            <Select value={formData.presentation} onValueChange={(value) => handleSelectChange("presentation", value)}>
              <SelectTrigger className="w-full bg-white">
                <SelectValue placeholder="Seleccionar presentación" />
              </SelectTrigger>
              <SelectContent>
                {PRESENTATION_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Número de Lote/Batch</label>
            <Input 
              type="text" 
              name="batch_number" 
              value={formData.batch_number} 
              onChange={handleChange}
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Fecha de Producción *</label>
            <Input 
              type="date" 
              name="production_date" 
              value={formData.production_date} 
              onChange={handleChange} 
              required 
              className="bg-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Fecha de Despacho *</label>
            <Input 
              type="date" 
              name="shipping_date" 
              value={formData.shipping_date} 
              onChange={handleChange} 
              required 
              className="bg-white"
            />
          </div>
        </div>
      </div>

      {/* SECCIÓN 4: DESCRIPCIÓN DEL RECLAMO */}
      <div className="border-2 border-slate-200 bg-white p-6 rounded-lg">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Descripción del Reclamo</h2>
        <textarea
          name="claim_description"
          value={formData.claim_description}
          onChange={handleChange}
          placeholder="Describe detalladamente el reclamo, qué pasó, cuáles son los síntomas o problemas observados..."
          className="w-full min-h-32 px-3 py-2 border border-slate-300 rounded-md bg-white"
        />
      </div>

      {/* SECCIÓN 5: FOTOS Y VIDEOS DE EVIDENCIA */}
      <div className="border-2 border-slate-200 bg-white p-6 rounded-lg">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Fotos y Videos de Evidencia</h2>
        
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*,video/*"
          onChange={handleMediaUpload}
          className="hidden"
        />
        
        <Button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          variant="outline"
          className="mb-4 border-slate-300 text-slate-700 hover:bg-slate-100"
        >
          + Agregar Fotos/Videos
        </Button>

        {formData.media_urls.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {formData.media_urls.map((url, index) => (
              <div key={index} className="relative group">
                {url.startsWith("data:image") ? (
                  <img 
                    src={url || "/placeholder.svg"} 
                    alt={`Media ${index + 1}`} 
                    className="w-full h-32 object-cover rounded-lg border border-slate-300"
                  />
                ) : (
                  <div className="w-full h-32 bg-gray-200 rounded-lg border border-slate-300 flex items-center justify-center">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() => removeMedia(index)}
                  className="absolute top-1 right-1 bg-red-500 text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* SECCIÓN 6: OBSERVACIONES */}
      <div className="border-2 border-slate-200 p-6 rounded-lg">
        <h2 className="text-lg font-bold text-slate-900 mb-4">Observaciones Adicionales</h2>
        <textarea
          name="observations"
          value={formData.observations}
          onChange={handleChange}
          className="w-full min-h-24 px-3 py-2 border rounded-md bg-white"
          placeholder="Observaciones adicionales o notas importantes..."
        />
      </div>

      {/* BOTONES DE ACCIÓN */}
      <div className="flex flex-col sm:flex-row gap-3 items-center pt-4 border-t-2">
        <div className="relative">
          <Button 
            type="submit" 
            disabled={isLoading || !isFormValid()} 
            className={`px-6 py-2 text-white ${isFormValid() ? "bg-blue-600 hover:bg-blue-700" : "bg-gray-400 cursor-not-allowed"}`}
          >
            {isLoading ? "Guardando..." : "Guardar Reclamo"}
          </Button>
          
          {showSuccessToast && (
            <div className="absolute left-0 -top-20 bg-white border-2 border-green-500 rounded-lg p-4 shadow-xl z-50 min-w-max animate-in fade-in slide-in-from-bottom-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div>
                  <p className="font-semibold text-green-700">¡Reclamo Guardado!</p>
                  <p className="text-sm text-green-600">Puedes generar el PDF desde Mis Reclamos</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {!isOnline && (
          <span className="text-sm text-amber-600 bg-amber-50 px-3 py-2 rounded border border-amber-200">
            Modo Offline - Sincronizará al conectarse
          </span>
        )}
      </div>
    </form>
  )
}
