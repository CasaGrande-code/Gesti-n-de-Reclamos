"use client"

import { useEffect, useState } from "react"

export function DBInitializer() {
  const [initialized, setInitialized] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const initializeDB = async () => {
      try {
        // Verificar si ya fue inicializado en esta sesión
        const sessionInit = sessionStorage.getItem("db_initialized")
        if (sessionInit) {
          setInitialized(true)
          return
        }

        console.log("[v0] Initializing database...")

        const response = await fetch("/api/init-db", {
          method: "POST",
        })

        if (response.ok) {
          const data = await response.json()
          console.log("[v0] Database initialized:", data.message)
          sessionStorage.setItem("db_initialized", "true")
          setInitialized(true)
        } else {
          const errorData = await response.json()
          console.error("[v0] Database init failed:", errorData)
          // No fallar la app, solo registrar
          setInitialized(true)
        }
      } catch (error) {
        console.error("[v0] Database initialization error:", error)
        // No fallar la app, solo registrar
        setError(String(error))
        setInitialized(true)
      }
    }

    initializeDB()
  }, [])

  // Este componente no renderiza nada, solo inicializa
  return null
}
