import { jsPDF } from "jspdf"

interface ClaimData {
  claim_code: string
  year: number
  company: string
  client: string
  claim_type: string
  claim_description: string
}

export function generateClaimPDF(claimData: ClaimData) {
  try {
    const doc = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "letter",
    })

    const pageWidth = doc.internal.pageSize.getWidth()
    const margin = 20
    const contentWidth = pageWidth - 2 * margin
    let yPosition = margin

    // Set default font
    doc.setFont("Helvetica", "normal")
    doc.setFontSize(10)
    doc.setTextColor(0, 0, 0)

    // Header with Date and Company - ALINEADO A LA DERECHA
    doc.setFontSize(11)
    const headerText = `${claimData.company}, ${new Date().toLocaleDateString("es-ES")}`
    const headerWidth = doc.getTextWidth(headerText)
    doc.text(headerText, pageWidth - margin - headerWidth, yPosition)
    yPosition += 10

    // Title - Carta (SIN el año/factura)
    doc.setFontSize(12)
    doc.setFont("Helvetica", "bold")
    doc.text(
      `Carta ${claimData.claim_code} N° ITR - ${claimData.company}`,
      margin,
      yPosition
    )
    yPosition += 12

    // Salutation
    doc.setFont("Helvetica", "normal")
    doc.setFontSize(10)
    doc.text("Señores:", margin, yPosition)
    yPosition += 8

    // Client name
    doc.setFont("Helvetica", "bold")
    doc.text(claimData.client, margin, yPosition)
    yPosition += 10

    // Greeting text
    doc.setFont("Helvetica", "normal")
    doc.text("De nuestra consideración,", margin, yPosition)
    yPosition += 10

    // Reference section
    doc.setFont("Helvetica", "bold")
    doc.text("REFERENCIA: " + claimData.claim_type, margin, yPosition)
    yPosition += 10

    // Body text
    doc.setFont("Helvetica", "normal")
    const bodyText =
      "Por medio del presente documento, nos dirigimos a usted con el fin de dar respuesta al reclamo presentado."
    const splitBodyText = doc.splitTextToSize(bodyText, contentWidth)
    doc.text(splitBodyText, margin, yPosition)
    yPosition += splitBodyText.length * 5 + 10

    // Description section title (SIN DUPLICAR)
    doc.setFont("Helvetica", "bold")
    doc.text("Descripción del Reclamo:", margin, yPosition)
    yPosition += 8

    // Claim description - SIN REPETIR LABEL
    doc.setFont("Helvetica", "normal")
    const splitDescription = doc.splitTextToSize(claimData.claim_description || "[Descripción del reclamo]", contentWidth)
    doc.text(splitDescription, margin, yPosition)
    yPosition += splitDescription.length * 5 + 10

    // Analysis section
    doc.setFont("Helvetica", "bold")
    doc.text("Análisis del Reclamo:", margin, yPosition)
    yPosition += 8

    doc.setFont("Helvetica", "normal")
    const analysisText =
      "Se tomó conocimiento del reclamo cursado por el cliente, el cual ha pasado a revisión y análisis de las áreas involucradas; para determinar las acciones que se implementarán para eliminar la causa de la no conformidad. Luego de este análisis les estaremos remitiendo el plan de acción que implementaremos."
    const splitAnalysisText = doc.splitTextToSize(analysisText, contentWidth)
    doc.text(splitAnalysisText, margin, yPosition)
    yPosition += splitAnalysisText.length * 5 + 8

    // Closing text
    const closingText =
      "Somos conscientes de nuestra constante preocupación por mantener la satisfacción de nuestros clientes, tenga por seguro que estamos trabajando para mejorar nuestros procesos a fin de que estos incidentes no se vuelvan a presentar."
    const splitClosingText = doc.splitTextToSize(closingText, contentWidth)
    doc.text(splitClosingText, margin, yPosition)
    yPosition += splitClosingText.length * 5 + 15

    // Closing salutation - A LA DERECHA
    doc.setFont("Helvetica", "normal")
    const closeingWidth = doc.getTextWidth("Atentamente,")
    doc.text("Atentamente,", pageWidth - margin - closeingWidth, yPosition)
    yPosition += 15

    // Signature line - A LA DERECHA
    doc.setDrawColor(0)
    doc.line(pageWidth - margin - 50, yPosition, pageWidth - margin, yPosition)
    yPosition += 10

    // Signature title - A LA DERECHA
    doc.setFontSize(9)
    const sigWidth = doc.getTextWidth("Superintendente SIG")
    doc.text("Superintendente SIG", pageWidth - margin - sigWidth, yPosition)

    // Add footer to all pages
    const pageCount = (doc as any).internal.getNumberOfPages()
    const pageHeight = doc.internal.pageSize.getHeight()
    const footerY = pageHeight - 10

    doc.setFontSize(8)
    doc.setFont("Helvetica", "normal")
    doc.setTextColor(0, 0, 0)

    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i)

      // Draw footer line
      doc.setDrawColor(150, 150, 150)
      doc.line(15, footerY - 5, pageWidth - 15, footerY - 5)

      // Left section
      doc.text("C01-GEGC-R-1.8", 20, footerY)
      doc.text("Pág. 1 de 1", 20, footerY + 4)

      // Center line separator
      doc.line(80, footerY - 4, 80, footerY + 4)

      // Center section
      const centerText1 = "CARTAVIO S.A.A. / CASAGRANDE S.A.A."
      const centerText1Width = doc.getTextWidth(centerText1)
      doc.text(centerText1, pageWidth / 2 - centerText1Width / 2, footerY)

      const centerText2 = "Prohibida su reproducción"
      const centerText2Width = doc.getTextWidth(centerText2)
      doc.text(centerText2, pageWidth / 2 - centerText2Width / 2, footerY + 4)

      // Right line separator
      doc.line(pageWidth - 80, footerY - 4, pageWidth - 80, footerY + 4)

      // Right section
      doc.text("Vigente", pageWidth - 50, footerY)
      doc.text("30/10/12", pageWidth - 50, footerY + 4)
      doc.text("02", pageWidth - 20, footerY)
    }

    // Generate PDF blob and download
    const pdfBlob = doc.output("blob")
    const url = URL.createObjectURL(pdfBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `Reclamo_${claimData.claim_code}_${claimData.year}.pdf`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  } catch (error) {
    console.error("[v0] Error generando PDF:", error)
  }
}
