// Exportar datos a Excel
export async function exportClaimsToExcel(claims: any[], kpis: any[]) {
  const { utils, writeFile } = await import("xlsx")

  const claimsData = claims.map((claim) => ({
    Código: claim.claim_code,
    Año: claim.year,
    Empresa: claim.company,
    Cliente: claim.client,
    Ubicación: claim.shipping_location,
    "Tipo de Cliente": claim.client_type,
    Producto: claim.product,
    Marca: claim.brand,
    Estado: claim.claim_status,
    Causa: claim.root_cause,
    "Fecha de Recepción": new Date(claim.reception_date).toLocaleDateString("es-ES"),
    "Fecha de Despacho": new Date(claim.shipping_date).toLocaleDateString("es-ES"),
  }))

  const kpisData = kpis.map((kpi) => ({
    Trimestre: kpi.quarter,
    Año: kpi.year,
    "KPI Comercial": kpi.commercial_kpi,
    "Días Despacho-Producción": kpi.shipping_days_kpi,
    "Tiempo de Atención": kpi.response_time_kpi,
    "Tiempo de Atención 2": kpi.response_time_2_kpi,
  }))

  const workbook = utils.book_new()
  const claimsSheet = utils.json_to_sheet(claimsData)
  const kpisSheet = utils.json_to_sheet(kpisData)

  utils.book_append_sheet(workbook, claimsSheet, "Reclamos")
  utils.book_append_sheet(workbook, kpisSheet, "KPIs")

  writeFile(workbook, `reclamos-${new Date().toISOString().split("T")[0]}.xlsx`)
}
