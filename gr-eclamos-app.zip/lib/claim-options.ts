// Opciones para los campos desplegables del formulario de reclamos

export const CLIENT_TYPE_OPTIONS = [
  { value: "Doméstico", label: "Doméstico" },
  { value: "Industrial", label: "Industrial" },
]

export const RECEPTION_METHOD_OPTIONS = [
  { value: "E-mail", label: "E-mail" },
  { value: "Llamada telefónica", label: "Llamada telefónica" },
  { value: "Whatsapp", label: "Whatsapp" },
  { value: "Visita In situ", label: "Visita In situ" },
  { value: "Otros", label: "Otros" },
]

export const PRODUCT_OPTIONS = [
  { value: "Az. Rubia", label: "Az. Rubia" },
  { value: "Az. Blanca", label: "Az. Blanca" },
  { value: "Az. Refinada", label: "Az. Refinada" },
]

export const BRAND_OPTIONS = [
  { value: "San Jacinto", label: "San Jacinto" },
  { value: "Cartavio", label: "Cartavio" },
  { value: "Casa Grande", label: "Casa Grande" },
  { value: "DulceOlmos", label: "DulceOlmos" },
  { value: "DulceAurora", label: "DulceAurora" },
  { value: "DulceNorte", label: "DulceNorte" },
  { value: "La Troncal", label: "La Troncal" },
  { value: "Marca cliente", label: "Marca cliente" },
]

export const PRESENTATION_OPTIONS = [
  { value: "Envase familiar", label: "Envase familiar" },
  { value: "Papel 50 kg", label: "Papel 50 kg" },
  { value: "PP 25 kg", label: "PP 25 kg" },
  { value: "PP + Liner 25 kg", label: "PP + Liner 25 kg" },
  { value: "PP 50 kg", label: "PP 50 kg" },
  { value: "PP + Liner 50 kg", label: "PP + Liner 50 kg" },
  { value: "Granel", label: "Granel" },
  { value: "Big Bag", label: "Big Bag" },
]

export const CLAIM_TYPE_OPTIONS = [
  { value: "Azúcar compactada", label: "Azúcar compactada" },
  { value: "Azúcar húmeda", label: "Azúcar húmeda" },
  { value: "Azúcar vencida", label: "Azúcar vencida" },
  { value: "Bolsas rotas o deterioradas", label: "Bolsas rotas o deterioradas" },
  { value: "Color no conforme", label: "Color no conforme" },
  { value: "Presentación equivocada", label: "Presentación equivocada" },
  { value: "Falta de peso", label: "Falta de peso" },
  { value: "Material extraño", label: "Material extraño" },
  { value: "Puntos negros", label: "Puntos negros" },
  { value: "NC microbiológica", label: "NC microbiológica" },
  { value: "Tamaño de grano no uniforme", label: "Tamaño de grano no uniforme" },
  { value: "Mal precintado de cisternas", label: "Mal precintado de cisternas" },
]

export const STATUS_OPTIONS = [
  { value: "Atendido", label: "Atendido" },
  { value: "Rechazado", label: "Rechazado" },
]
