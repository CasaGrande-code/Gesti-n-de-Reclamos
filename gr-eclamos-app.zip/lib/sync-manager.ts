// Gestor de sincronización offline-to-online
import { getSupabaseClient } from "@/lib/supabase-client"
import { getSyncQueue, clearSyncQueue } from "@/lib/offline-store"

export async function syncPendingClaims() {
  try {
    const supabase = getSupabaseClient()
    const syncQueue = await getSyncQueue()

    if (syncQueue.length === 0) {
      return { success: true, synced: 0 }
    }

    let synced = 0

    for (const item of syncQueue) {
      try {
        if (item.type === "insert") {
          const { error } = await supabase.from("claims").insert([item.data])
          if (error) throw error
          synced++
        }
      } catch (error) {
        console.error("[v0] Error syncing claim:", error)
        // Continuar con los siguientes items aunque falle uno
      }
    }

    if (synced === syncQueue.length) {
      await clearSyncQueue()
    }

    return { success: true, synced }
  } catch (error) {
    console.error("[v0] Sync error:", error)
    return { success: false, synced: 0 }
  }
}

export function setupSyncListener() {
  if (typeof window === "undefined") return

  // Sincronizar cuando se recupera la conexión
  window.addEventListener("online", async () => {
    console.log("[v0] Connection restored, syncing...")
    await syncPendingClaims()
  })
}
