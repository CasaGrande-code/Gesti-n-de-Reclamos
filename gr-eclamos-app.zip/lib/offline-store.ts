// IndexedDB para almacenamiento offline
const DB_NAME = "claims-app"
const DB_VERSION = 1

export interface OfflineStore {
  claims: any[]
  kpis: any[]
  syncQueue: any[]
}

let dbInstance: IDBDatabase | null = null

export async function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return dbInstance

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION)

    request.onerror = () => reject(request.error)
    request.onsuccess = () => {
      dbInstance = request.result
      resolve(dbInstance)
    }

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result

      if (!db.objectStoreNames.contains("claims")) {
        db.createObjectStore("claims", { keyPath: "id" })
      }
      if (!db.objectStoreNames.contains("kpis")) {
        db.createObjectStore("kpis", { keyPath: "id" })
      }
      if (!db.objectStoreNames.contains("syncQueue")) {
        db.createObjectStore("syncQueue", { keyPath: "id", autoIncrement: true })
      }
    }
  })
}

export async function saveClaimOffline(claim: any) {
  const db = await getDB()
  const tx = db.transaction(["claims", "syncQueue"], "readwrite")

  return new Promise((resolve, reject) => {
    const claimsStore = tx.objectStore("claims")
    const syncStore = tx.objectStore("syncQueue")

    claimsStore.put(claim)
    syncStore.add({ type: "insert", table: "claims", data: claim, timestamp: Date.now() })

    tx.oncomplete = () => resolve(claim)
    tx.onerror = () => reject(tx.error)
  })
}

export async function getClaimsOffline() {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const request = db.transaction("claims", "readonly").objectStore("claims").getAll()
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

export async function getSyncQueue() {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const request = db.transaction("syncQueue", "readonly").objectStore("syncQueue").getAll()
    request.onsuccess = () => resolve(request.result)
    request.onerror = () => reject(request.error)
  })
}

export async function clearSyncQueue() {
  const db = await getDB()
  return new Promise((resolve, reject) => {
    const request = db.transaction("syncQueue", "readwrite").objectStore("syncQueue").clear()
    request.onsuccess = () => resolve(null)
    request.onerror = () => reject(request.error)
  })
}
