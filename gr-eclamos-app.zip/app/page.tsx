"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 bg-blue-500 rounded-lg flex items-center justify-center text-white font-bold text-sm">
                RC
              </div>
              <h1 className="text-lg font-bold text-slate-900">Gestión de Reclamos</h1>
            </div>
            <p className="text-slate-600 text-sm hidden sm:block">v1.0</p>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl md:text-6xl font-bold text-slate-900 mb-6 leading-tight">
            Gestión de Reclamos
          </h1>
        </div>

        {/* Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Card: Nuevo Reclamo */}
          <Link href="/claims/new">
            <div className="group bg-blue-50 p-8 rounded-xl border border-blue-200 hover:bg-blue-100 hover:border-blue-400 transition-all duration-300 cursor-pointer hover:shadow-lg">
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-blue-200 transition">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Nuevo Reclamo</h3>
              <p className="text-slate-700 text-sm">Registra reclamos rápidamente con formulario intuitivo</p>
              <div className="mt-4 inline-flex items-center text-blue-600 text-sm font-medium">
                Crear reclamo <span className="ml-2">→</span>
              </div>
            </div>
          </Link>

          {/* Card: Dashboard */}
          <Link href="/dashboard">
            <div className="group bg-green-50 p-8 rounded-xl border border-green-200 hover:bg-green-100 hover:border-green-400 transition-all duration-300 cursor-pointer hover:shadow-lg">
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-green-200 transition">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Dashboard de KPIs</h3>
              <p className="text-slate-700 text-sm">Analiza métricas y desempeño en tiempo real</p>
              <div className="mt-4 inline-flex items-center text-green-600 text-sm font-medium">
                Ver análisis <span className="ml-2">→</span>
              </div>
            </div>
          </Link>

          {/* Card: Mis Reclamos */}
          <Link href="/claims">
            <div className="group bg-purple-50 p-8 rounded-xl border border-purple-200 hover:bg-purple-100 hover:border-purple-400 transition-all duration-300 cursor-pointer hover:shadow-lg">
              <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-purple-200 transition">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-slate-900 mb-2">Mis Reclamos</h3>
              <p className="text-slate-700 text-sm">Gestiona y monitorea todos tus reclamos</p>
              <div className="mt-4 inline-flex items-center text-purple-600 text-sm font-medium">
                Ver listado <span className="ml-2">→</span>
              </div>
            </div>
          </Link>
        </div>

        {/* Features Section */}
        <div className="bg-slate-50 p-8 rounded-xl border border-slate-200">
          <h2 className="text-3xl font-bold text-slate-900 mb-8">Características Principales</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100">
                  <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Registro Ágil</h3>
                <p className="text-slate-700 text-sm mt-1">Formulario intuitivo para capturar reclamos rápidamente</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100">
                  <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Análisis en Tiempo Real</h3>
                <p className="text-slate-700 text-sm mt-1">Gráficos y KPIs actualizados constantemente</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100">
                  <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Sincronización Offline</h3>
                <p className="text-slate-700 text-sm mt-1">Funciona sin conexión y sincroniza automáticamente</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center h-10 w-10 rounded-md bg-blue-100">
                  <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                </div>
              </div>
              <div>
                <h3 className="text-lg font-medium text-slate-900">Exportación a Excel</h3>
                <p className="text-slate-700 text-sm mt-1">Descarga datos en formato Excel para análisis</p>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="mt-12 text-center">
          <Link href="/claims/new">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition">
              Comenzar Ahora
            </Button>
          </Link>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-slate-600 text-sm">
          <p>Sistema de Gestión de Reclamos v1.0 • Powered by Supabase & Next.js</p>
        </div>
      </footer>
    </div>
  )
}
