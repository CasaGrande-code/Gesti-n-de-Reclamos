"use client"

import { useRouter } from "next/navigation"
import { KPIsDashboard } from "@/components/kpis-dashboard"
import { Button } from "@/components/ui/button"

export default function DashboardPage() {
  const router = useRouter()

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={() => router.push("/")} className="text-slate-600">
                ← Inicio
              </Button>
              <h1 className="text-xl font-bold text-slate-900">Dashboard de KPIs</h1>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <KPIsDashboard />
      </main>
    </div>
  )
}
