"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSupabaseClient } from "@/lib/supabase-client"
import { generateClaimPDF } from "@/lib/pdf-generator"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { toast } from "sonner"

export default function ClaimsListPage() {
  const [claims, setClaims] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [selectedClaim, setSelectedClaim] = useState(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const router = useRouter()
  const supabase = getSupabaseClient()

  useEffect(() => {
    const loadClaims = async () => {
      try {
        const { data, error } = await supabase
          .from("claims")
          .select("*")
          .order("created_at", { ascending: false })

        if (error) {
          console.error("[v0] Error loading claims:", error)
        } else {
          setClaims(data || [])
        }
      } catch (error) {
        console.error("[v0] Error:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadClaims()
  }, [supabase])

  const handleDeleteClaim = async (claimId: string) => {
    if (!window.confirm("¿Estás seguro de que deseas eliminar este reclamo?")) {
      return
    }

    try {
      const { error } = await supabase.from("claims").delete().eq("id", claimId)

      if (error) {
        throw error
      }

      setClaims(claims.filter((claim) => claim.id !== claimId))
      toast.success("Reclamo eliminado correctamente")
    } catch (error) {
      console.error("[v0] Error deleting claim:", error)
      toast.error("Error al eliminar el reclamo")
    }
  }

  const handleStatusChange = async (claimId: string, newStatus: string) => {
    try {
      const { error } = await supabase.from("claims").update({ claim_status: newStatus }).eq("id", claimId)

      if (error) {
        throw error
      }

      setClaims(claims.map((claim) => (claim.id === claimId ? { ...claim, claim_status: newStatus } : claim)))
      toast.success("Estado actualizado correctamente")
    } catch (error) {
      console.error("[v0] Error updating status:", error)
      toast.error("Error al actualizar el estado")
    }
  }

  const openClaimDetails = (claim: any) => {
    setSelectedClaim(claim)
    setIsModalOpen(true)
  }

  const getStatusLabel = (status: string) => {
    const statusMap: { [key: string]: string } = {
      received: "Recibido",
      in_analysis: "En Análisis",
      resolved: "Resuelto",
      closed: "Cerrado",
    }
    return statusMap[status] || status
  }

  const getStatusColor = (status: string) => {
    const colorMap: { [key: string]: string } = {
      received: "bg-blue-100 text-blue-700",
      pending: "bg-yellow-100 text-yellow-700",
      resolved: "bg-green-100 text-green-700",
      closed: "bg-slate-100 text-slate-700",
    }
    return colorMap[status] || "bg-slate-100 text-slate-700"
  }

  if (isLoading)
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin">
          <div className="h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
        </div>
      </div>
    )

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Button variant="ghost" onClick={() => router.push("/")} className="text-slate-600">
              ← Volver al Inicio
            </Button>
            <h1 className="text-xl font-bold text-slate-900">Mis Reclamos</h1>
            <Button onClick={() => router.push("/claims/new")} className="bg-primary text-primary-foreground">
              + Nuevo Reclamo
            </Button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white p-8 rounded-lg border border-slate-200">
          {claims.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-slate-600 mb-4">No hay reclamos registrados</p>
              <Button onClick={() => router.push("/claims/new")} className="bg-primary text-primary-foreground">
                Crear Primer Reclamo
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {claims.map((claim) => (
                <div key={claim.id} className="p-4 border border-slate-200 rounded-lg hover:bg-slate-50 transition">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                    {/* Código */}
                    <div>
                      <p className="text-xs text-slate-500 font-semibold">Código</p>
                      <p className="text-sm font-medium text-slate-900">{claim.claim_code}</p>
                    </div>

                    {/* Cliente y Producto */}
                    <div>
                      <p className="text-xs text-slate-500 font-semibold">Cliente / Producto</p>
                      <p className="text-sm text-slate-600">{claim.client}</p>
                      <p className="text-xs text-slate-500">{claim.product}</p>
                    </div>

                    {/* Responsable Comercial */}
                    <div>
                      <p className="text-xs text-slate-500 font-semibold">Responsable</p>
                      <p className="text-sm text-slate-600">{claim.responsible_process || "—"}</p>
                    </div>

                    {/* Estado */}
                    <div>
                      <p className="text-xs text-slate-500 font-semibold">Estado</p>
                      <Select value={claim.claim_status} onValueChange={(value) => handleStatusChange(claim.id, value)}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Seleccionar estado" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="received">Recibido</SelectItem>
                          <SelectItem value="in_analysis">En Análisis</SelectItem>
                          <SelectItem value="resolved">Resuelto</SelectItem>
                          <SelectItem value="closed">Cerrado</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Acciones */}
                    <div className="flex gap-2 flex-col">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openClaimDetails(claim)}
                        className="w-full text-xs"
                      >
                        Ver Detalles
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDeleteClaim(claim.id)}
                        className="w-full text-xs"
                      >
                        Eliminar
                      </Button>
                    </div>
                  </div>

                  {/* Fecha de creación */}
                  <div className="mt-2 text-xs text-slate-500">
                    Creado: {new Date(claim.created_at).toLocaleDateString("es-ES", { weekday: "short", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </main>

      {/* Modal de Detalles */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-h-[80vh] overflow-y-auto max-w-4xl">
          <DialogHeader>
            <DialogTitle>Detalles del Reclamo - {selectedClaim?.claim_code}</DialogTitle>
          </DialogHeader>
          {selectedClaim && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="font-semibold text-slate-600">Código</p>
                  <p className="text-slate-900">{selectedClaim.claim_code}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">N° de Factura</p>
                  <p className="text-slate-900">{selectedClaim.year}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Empresa</p>
                  <p className="text-slate-900">{selectedClaim.company}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Cliente</p>
                  <p className="text-slate-900">{selectedClaim.client}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Requerimiento de Cliente</p>
                  <p className="text-slate-900">{selectedClaim.client_requirement || "—"}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Responsable Comercial</p>
                  <p className="text-slate-900">{selectedClaim.commercial_responsible || "—"}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Recepción de Reclamo - Comercial</p>
                  <p className="text-slate-900">{new Date(selectedClaim.reception_date).toLocaleDateString("es-ES")}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Tipo de Cliente</p>
                  <p className="text-slate-900">{selectedClaim.client_type}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Tipo de Reclamo</p>
                  <p className="text-slate-900">{selectedClaim.claim_type || "—"}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Producto</p>
                  <p className="text-slate-900">{selectedClaim.product}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Marca</p>
                  <p className="text-slate-900">{selectedClaim.brand}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Presentación</p>
                  <p className="text-slate-900">{selectedClaim.presentation || "—"}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Lote/Batch</p>
                  <p className="text-slate-900">{selectedClaim.batch_number || "—"}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Método de Recepción</p>
                  <p className="text-slate-900">{selectedClaim.received_through}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Lugar de Despacho</p>
                  <p className="text-slate-900">{selectedClaim.shipping_location}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Fecha de Producción</p>
                  <p className="text-slate-900">{new Date(selectedClaim.production_date).toLocaleDateString("es-ES")}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Fecha de Despacho</p>
                  <p className="text-slate-900">{new Date(selectedClaim.shipping_date).toLocaleDateString("es-ES")}</p>
                </div>
                <div>
                  <p className="font-semibold text-slate-600">Fecha de Recepción al GC</p>
                  <p className="text-slate-900">{selectedClaim.reception_date_sig ? new Date(selectedClaim.reception_date_sig).toLocaleDateString("es-ES") : "—"}</p>
                </div>
              </div>

              {selectedClaim.claim_description && (
                <div className="border-t pt-4">
                  <p className="font-semibold text-slate-600 mb-2">Descripción del Reclamo</p>
                  <p className="text-slate-900 whitespace-pre-wrap text-sm bg-green-50 p-3 rounded border border-green-200">{selectedClaim.claim_description}</p>
                </div>
              )}

              {selectedClaim.observations && (
                <div className="border-t pt-4">
                  <p className="font-semibold text-slate-600 mb-2">Observaciones</p>
                  <p className="text-slate-900 whitespace-pre-wrap text-sm bg-slate-50 p-3 rounded border border-slate-200">{selectedClaim.observations}</p>
                </div>
              )}

              {selectedClaim.media_urls && Array.isArray(selectedClaim.media_urls) && selectedClaim.media_urls.length > 0 && (
                <div className="border-t pt-4">
                  <p className="font-semibold text-slate-600 mb-3">Fotos y Videos de Evidencia</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {selectedClaim.media_urls.map((url: string, index: number) => (
                      <div key={index} className="relative group overflow-hidden rounded-lg border border-purple-200">
                        {url.startsWith("data:image") ? (
                          <a href={url} download={`reclamo-${selectedClaim.claim_code}-media-${index + 1}`}>
                            <img 
                              src={url || "/placeholder.svg"} 
                              alt={`Media ${index + 1}`} 
                              className="w-full h-32 object-cover hover:scale-105 transition cursor-pointer"
                            />
                          </a>
                        ) : (
                          <a href={url} download>
                            <div className="w-full h-32 bg-gray-200 flex items-center justify-center rounded hover:bg-gray-300 transition cursor-pointer">
                              <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                              </svg>
                            </div>
                          </a>
                        )}
                        <p className="text-xs text-slate-600 p-1 absolute bottom-0 left-0 right-0 bg-black/40 text-white">Media {index + 1}</p>
                        <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition">
                          <a 
                            href={url} 
                            download={`reclamo-${selectedClaim.claim_code}-media-${index + 1}`}
                            className="bg-blue-500 hover:bg-blue-600 text-white rounded-full p-1"
                            title="Descargar"
                          >
                            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="border-t pt-4 flex gap-2">
                <Button
                  onClick={() => generateClaimPDF(selectedClaim)}
                  className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  Generar PDF
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
