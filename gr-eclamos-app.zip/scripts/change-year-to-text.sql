-- Alter the year column from INTEGER to TEXT
ALTER TABLE claims ALTER COLUMN year SET DATA TYPE TEXT;
