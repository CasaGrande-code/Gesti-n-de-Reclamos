-- Insert default system user for testing
INSERT INTO users (id, email, full_name, role)
VALUES (
  'a0000000-0000-0000-0000-000000000001'::uuid,
  'system@claims.local',
  'Sistema',
  'admin'
)
ON CONFLICT (id) DO NOTHING;

COMMIT;
