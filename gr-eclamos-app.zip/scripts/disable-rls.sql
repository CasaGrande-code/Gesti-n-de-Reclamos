-- Desabilitar RLS en la tabla claims para desarrollo
ALTER TABLE claims DISABLE ROW LEVEL SECURITY;
