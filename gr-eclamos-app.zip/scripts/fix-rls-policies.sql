-- Drop all existing policies
DROP POLICY IF EXISTS "Public can view users" ON users;
DROP POLICY IF EXISTS "Public can insert users" ON users;
DROP POLICY IF EXISTS "Anyone can view users" ON users;
DROP POLICY IF EXISTS "Anyone can insert users" ON users;
DROP POLICY IF EXISTS "Anyone can update users" ON users;
DROP POLICY IF EXISTS "Users can view their own data" ON users;
DROP POLICY IF EXISTS "Users can update their own data" ON users;
DROP POLICY IF EXISTS "Public can view all claims" ON claims;
DROP POLICY IF EXISTS "Public can insert claims" ON claims;
DROP POLICY IF EXISTS "Public can update claims" ON claims;
DROP POLICY IF EXISTS "Anyone can view claims" ON claims;
DROP POLICY IF EXISTS "Anyone can insert claims" ON claims;
DROP POLICY IF EXISTS "Anyone can update claims" ON claims;
DROP POLICY IF EXISTS "Authenticated users can view claims" ON claims;
DROP POLICY IF EXISTS "Authenticated users can insert claims" ON claims;
DROP POLICY IF EXISTS "Users can update claims" ON claims;
DROP POLICY IF EXISTS "Public can view KPIs" ON kpis;
DROP POLICY IF EXISTS "Anyone can view KPIs" ON kpis;
DROP POLICY IF EXISTS "Anyone can insert KPIs" ON kpis;
DROP POLICY IF EXISTS "Anyone can update KPIs" ON kpis;
DROP POLICY IF EXISTS "All authenticated users can view KPIs" ON kpis;
DROP POLICY IF EXISTS "All authenticated users can manage KPIs" ON kpis;
DROP POLICY IF EXISTS "Authenticated users can update KPIs" ON kpis;
DROP POLICY IF EXISTS "Public can view audit logs" ON audit_logs;
DROP POLICY IF EXISTS "Anyone can view audit logs" ON audit_logs;
DROP POLICY IF EXISTS "Anyone can insert audit logs" ON audit_logs;

-- Create permissive policies for development/preview
-- Users table
CREATE POLICY "read_users" ON users FOR SELECT USING (true);
CREATE POLICY "insert_users" ON users FOR INSERT WITH CHECK (true);
CREATE POLICY "update_users" ON users FOR UPDATE USING (true);
CREATE POLICY "delete_users" ON users FOR DELETE USING (true);

-- Claims table - Allow all operations
CREATE POLICY "read_claims" ON claims FOR SELECT USING (true);
CREATE POLICY "insert_claims" ON claims FOR INSERT WITH CHECK (true);
CREATE POLICY "update_claims" ON claims FOR UPDATE USING (true);
CREATE POLICY "delete_claims" ON claims FOR DELETE USING (true);

-- KPIs table - Allow all operations
CREATE POLICY "read_kpis" ON kpis FOR SELECT USING (true);
CREATE POLICY "insert_kpis" ON kpis FOR INSERT WITH CHECK (true);
CREATE POLICY "update_kpis" ON kpis FOR UPDATE USING (true);
CREATE POLICY "delete_kpis" ON kpis FOR DELETE USING (true);

-- Audit logs - Allow all operations
CREATE POLICY "read_audit_logs" ON audit_logs FOR SELECT USING (true);
CREATE POLICY "insert_audit_logs" ON audit_logs FOR INSERT WITH CHECK (true);
