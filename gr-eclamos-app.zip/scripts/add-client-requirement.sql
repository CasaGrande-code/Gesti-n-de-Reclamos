-- Add client_requirement column to claims table
ALTER TABLE claims ADD COLUMN IF NOT EXISTS client_requirement TEXT;
