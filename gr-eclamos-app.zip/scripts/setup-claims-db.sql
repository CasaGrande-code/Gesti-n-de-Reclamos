-- Enable extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Create enum types
CREATE TYPE user_role AS ENUM ('admin', 'supervisor', 'operator');
CREATE TYPE claim_status AS ENUM ('received', 'in_analysis', 'resolved', 'closed');

-- Create users table with roles
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role user_role DEFAULT 'operator',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create claims table
CREATE TABLE IF NOT EXISTS claims (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  claim_code TEXT UNIQUE NOT NULL,
  year INTEGER NOT NULL,
  company TEXT NOT NULL,
  client TEXT NOT NULL,
  shipping_location TEXT NOT NULL,
  client_type TEXT NOT NULL,
  received_by UUID NOT NULL REFERENCES users(id),
  reception_date TIMESTAMP WITH TIME ZONE NOT NULL,
  reception_date_sig TIMESTAMP WITH TIME ZONE,
  received_through TEXT,
  product TEXT NOT NULL,
  brand TEXT NOT NULL,
  presentation TEXT,
  batch_number TEXT,
  total_billing_date TIMESTAMP WITH TIME ZONE,
  production_date TIMESTAMP WITH TIME ZONE NOT NULL,
  shipping_date TIMESTAMP WITH TIME ZONE NOT NULL,
  claim_status claim_status DEFAULT 'received',
  status_reason TEXT,
  root_cause TEXT,
  responsible_process TEXT,
  first_response_date TIMESTAMP WITH TIME ZONE,
  second_response_date TIMESTAMP WITH TIME ZONE,
  observations TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create KPIs table
CREATE TABLE IF NOT EXISTS kpis (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  quarter INTEGER NOT NULL,
  year INTEGER NOT NULL,
  commercial_kpi DECIMAL(10, 2),
  shipping_days_kpi DECIMAL(10, 2),
  response_time_kpi DECIMAL(10, 2),
  response_time_2_kpi DECIMAL(10, 2),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(quarter, year)
);

-- Create audit logs table
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  table_name TEXT NOT NULL,
  record_id UUID,
  changes JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX idx_claims_code ON claims(claim_code);
CREATE INDEX idx_claims_year ON claims(year);
CREATE INDEX idx_claims_status ON claims(claim_status);
CREATE INDEX idx_claims_received_by ON claims(received_by);
CREATE INDEX idx_kpis_quarter_year ON kpis(quarter, year);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_table ON audit_logs(table_name);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE kpis ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
CREATE POLICY "Users can view their own data" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admins can view all users" ON users
  FOR SELECT USING (
    auth.uid() IN (SELECT id FROM users WHERE role = 'admin')
  );

CREATE POLICY "Users can update their own data" ON users
  FOR UPDATE USING (auth.uid() = id);

-- Create policies for claims table
CREATE POLICY "Operators can view claims they received" ON claims
  FOR SELECT USING (received_by = auth.uid());

CREATE POLICY "Supervisors can view all claims" ON claims
  FOR SELECT USING (
    auth.uid() IN (SELECT id FROM users WHERE role IN ('supervisor', 'admin'))
  );

CREATE POLICY "Authenticated users can insert claims" ON claims
  FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Users can update their claims" ON claims
  FOR UPDATE USING (
    received_by = auth.uid() OR 
    auth.uid() IN (SELECT id FROM users WHERE role IN ('supervisor', 'admin'))
  );

-- Create policies for KPIs table
CREATE POLICY "All authenticated users can view KPIs" ON kpis
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins and supervisors can manage KPIs" ON kpis
  FOR INSERT WITH CHECK (
    auth.uid() IN (SELECT id FROM users WHERE role IN ('supervisor', 'admin'))
  );

-- Create update trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_claims_updated_at BEFORE UPDATE ON claims
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_kpis_updated_at BEFORE UPDATE ON kpis
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
