-- Insertar usuarios de ejemplo (admin y supervisor)
INSERT INTO users (id, email, full_name, role) VALUES
('11111111-1111-1111-1111-111111111111', 'admin@example.com', 'Admin User', 'admin'),
('22222222-2222-2222-2222-222222222222', 'supervisor@example.com', 'Supervisor User', 'supervisor'),
('33333333-3333-3333-3333-333333333333', 'operator@example.com', 'Operario User', 'operator')
ON CONFLICT (id) DO NOTHING;

-- Insertar KPIs de ejemplo para diferentes trimestres
INSERT INTO kpis (year, quarter, commercial_kpi, shipping_days_kpi, response_time_kpi, response_time_2_kpi) VALUES
(2024, 1, 85.5, 3.2, 2.1, 1.8),
(2024, 2, 87.3, 3.5, 2.3, 2.0),
(2024, 3, 88.2, 3.1, 2.0, 1.9),
(2024, 4, 90.1, 2.9, 1.9, 1.7),
(2025, 1, 91.5, 3.0, 2.2, 2.1)
ON CONFLICT DO NOTHING;

-- Insertar reclamos de ejemplo
INSERT INTO claims (
  claim_code, year, company, client, shipping_location, client_type,
  received_by, reception_date, product, brand, presentation, batch_number,
  production_date, shipping_date, claim_status, created_at
) VALUES
('REC-2024-001', 2024, 'Empresa A', 'Cliente XYZ', 'Bogotá', 'Mayorista',
 '11111111-1111-1111-1111-111111111111', NOW() - INTERVAL '30 days', 
 'Producto 1', 'Marca A', 'Presentación 500ml', 'BATCH-001',
 NOW() - INTERVAL '40 days', NOW() - INTERVAL '35 days', 'resolved', NOW() - INTERVAL '30 days'),
('REC-2024-002', 2024, 'Empresa B', 'Cliente ABC', 'Medellín', 'Distribuidor',
 '22222222-2222-2222-2222-222222222222', NOW() - INTERVAL '20 days',
 'Producto 2', 'Marca B', 'Presentación 1L', 'BATCH-002',
 NOW() - INTERVAL '30 days', NOW() - INTERVAL '25 days', 'in_analysis', NOW() - INTERVAL '20 days'),
('REC-2024-003', 2024, 'Empresa C', 'Cliente DEF', 'Cali', 'Minorista',
 '33333333-3333-3333-3333-333333333333', NOW() - INTERVAL '10 days',
 'Producto 3', 'Marca C', 'Presentación 250ml', 'BATCH-003',
 NOW() - INTERVAL '20 days', NOW() - INTERVAL '15 days', 'closed', NOW() - INTERVAL '10 days')
ON CONFLICT (claim_code) DO NOTHING;
