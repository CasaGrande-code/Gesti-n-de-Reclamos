-- Make received_by nullable to allow claims without assigned user
ALTER TABLE claims ALTER COLUMN received_by DROP NOT NULL;
